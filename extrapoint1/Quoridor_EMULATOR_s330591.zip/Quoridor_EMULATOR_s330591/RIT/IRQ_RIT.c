/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../GLCD/GLCD.h"
#include "../Game.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

volatile int down_0=0;
volatile int down_1=0;
volatile int down_2=0;
int flag = 0;

extern G g;
extern uint16_t game_color;
extern uint16_t background_color;
extern uint16_t Hmoves_color;
extern uint16_t positioned_wall_color;
extern uint16_t error_color;

void RIT_IRQHandler (void)
{
	static int J_select = 0;
	static int J_down = 0;
	static int J_high = 0;
	static int J_left = 0;
	static int J_right = 0;	
	int t, r;
		
	if((LPC_GPIO1->FIOPIN & (1<<25)) == 0){	
		
		J_select++;
		switch(J_select){
			case 1: 
				if (g.game_mode == 0 ){
					if ( g.mossa_sospesa.v > -1) {
						Confirmed_move(&g);
					}
				}
				else if (g.game_mode == 1){
					Positionate_wall (&g);
				}
				break;
			default:
				break;
		}
	}
	else{
			J_select=0;
	}
	
	
	
	if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){	
		
		J_down++;
		switch(J_down){
			case 1: 
				if (g.game_mode == 0){
					int c;
					if (flag){
						GUI_Text(0, 241, (uint8_t *) "                               ", background_color , background_color);
						flag = 0;
					}
					if ((c = Check_down (g.mossa_sospesa.x, g.mossa_sospesa.y, &g))){
						Erase_old_Hmove (&(g.mossa_sospesa));
						g.mossa_sospesa.v = (c-2)*2 + 1;
						Make_new_Hmove (&(g.mossa_sospesa));
					}
				}
				else if (g.game_mode == 1){
					if (g.muro_sospeso.y == 11) {
						LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
						LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
					}
					else if (g.muro_sospeso.v == 0){
						
						for (t = 2; t < 12; t += 2){
							if (g.i[g.muro_sospeso.x][g.muro_sospeso.y + t] == 0 &&
								g.i[g.muro_sospeso.x + 1][g.muro_sospeso.y + t] == 0 &&
							g.i[g.muro_sospeso.x - 1][g.muro_sospeso.y + t] == 0){
								
								LCD_Move_Full_Rectangle( &(g.muro_sospeso), 2*(t-2) + 1);
								break;
							}
							else if (g.muro_sospeso.y + t == 11){
								if (anyMoves(&g) == 0){
									LCD_Draw_Full_Rectangle(g.muro_sospeso, background_color);
									t = g.muro_sospeso.x;
									r = g.muro_sospeso.y;
									g.i[t][r] = 1;
									Search_free_place ( &(g.muro_sospeso), g.i);
									g.i[t][r] = 0;
									LCD_Draw_Full_Rectangle( g.muro_sospeso, g.muro_sospeso.color );
								}
								else {
									LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
									LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
								}
								break;
							}
						}
					}
					else if (g.muro_sospeso.v == 1){
						
						for (t = 2; t < 12; t += 2){	
							if (g.i[g.muro_sospeso.x][g.muro_sospeso.y + t] == 0 &&
								g.i[g.muro_sospeso.x][g.muro_sospeso.y + t - 1] == 0 &&
							g.i[g.muro_sospeso.x][g.muro_sospeso.y + t + 1] == 0){
								
								LCD_Move_Full_Rectangle( &(g.muro_sospeso), 2*(t-2) + 1);
								break;
							}
							else if (g.muro_sospeso.y + t == 11){
								if (anyMoves(&g) == 0){
									LCD_Draw_Full_Rectangle(g.muro_sospeso, background_color);
									t = g.muro_sospeso.x;
									r = g.muro_sospeso.y;
									g.i[t][r] = 1;
									Search_free_place ( &(g.muro_sospeso), g.i);
									g.i[t][r] = 0;
									LCD_Draw_Full_Rectangle( g.muro_sospeso, g.muro_sospeso.color );
								}
								else {
									LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
									LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
								}
								break;
							}
						}
					}
					else{
						LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
						LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
					}
					break;
				}
			default:
				break;
		}
	}
	else{
			J_down=0;
	}
	
	
	
	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	
		
		J_high++;
		switch(J_high){
			case 1:
				if (g.game_mode == 0)  {
					int c;
					if (flag){
						GUI_Text(0, 241, (uint8_t *) "                               ", background_color , background_color);
						flag = 0;
					}
					if ((c = Check_high (g.mossa_sospesa.x, g.mossa_sospesa.y, &g))){
						Erase_old_Hmove (&(g.mossa_sospesa));
						g.mossa_sospesa.v = (c-2)*2;
						Make_new_Hmove (&(g.mossa_sospesa));
					}
				}
				else if (g.game_mode == 1){
					if (g.muro_sospeso.y == 1) {
						LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
						LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
					}
					else if (g.muro_sospeso.v == 0){
						
						for (t = 2; t < 12; t += 2){
							if (g.i[g.muro_sospeso.x][g.muro_sospeso.y - t] == 0 &&
								g.i[g.muro_sospeso.x + 1][g.muro_sospeso.y - t] == 0 &&
							g.i[g.muro_sospeso.x - 1][g.muro_sospeso.y - t] == 0){
								LCD_Move_Full_Rectangle( &(g.muro_sospeso), 2*(t-2));
								break;
							}
							else if (g.muro_sospeso.y - t == 1){
								if (anyMoves(&g) == 0){
									LCD_Draw_Full_Rectangle(g.muro_sospeso, background_color);
									t = g.muro_sospeso.x;
									r = g.muro_sospeso.y;
									g.i[t][r] = 1;
									Search_free_place ( &(g.muro_sospeso), g.i);
									g.i[t][r] = 0;
									LCD_Draw_Full_Rectangle( g.muro_sospeso, g.muro_sospeso.color );
								}
								else {
								LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
								LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
								}
								break;
							}
						}
					}
					else if (g.muro_sospeso.v == 1){
						for (t = 2; t < 12; t += 2){
							
							if (g.i[g.muro_sospeso.x][g.muro_sospeso.y - t] == 0 &&
								g.i[g.muro_sospeso.x][g.muro_sospeso.y - t - 1] == 0 &&
							g.i[g.muro_sospeso.x][g.muro_sospeso.y - t + 1] == 0){
								
								LCD_Move_Full_Rectangle( &(g.muro_sospeso), 2*(t-2));
								break;
								
							}
							else if (g.muro_sospeso.y - t == 1){
									if (anyMoves(&g) == 0){
									LCD_Draw_Full_Rectangle(g.muro_sospeso, background_color);
									t = g.muro_sospeso.x;
									r = g.muro_sospeso.y;
									g.i[t][r] = 1;
									Search_free_place ( &(g.muro_sospeso), g.i);
									g.i[t][r] = 0;
									LCD_Draw_Full_Rectangle( g.muro_sospeso, g.muro_sospeso.color );
								}
									else {
										LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
										LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
									}
								break;
							}
						}
					}
					else{
						LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
						LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
					}
					break;
			}
			default:
				break;
		}
	}
	else{
			J_high=0;
	}
	
	
	
	if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){	
		
		J_left++;
		switch(J_left){
			case 1:
				if (g.game_mode == 0) {
					int c;
					if (flag){
						GUI_Text(0, 241, (uint8_t *) "                               ", background_color , background_color);
						flag = 0;
					}
					if ((c = Check_left (g.mossa_sospesa.x, g.mossa_sospesa.y, &g))){
						Erase_old_Hmove (&(g.mossa_sospesa));
						g.mossa_sospesa.v = (c-2)*2 + 2;
						Make_new_Hmove (&(g.mossa_sospesa));
					}
				}
				else if (g.game_mode == 1){
					if (g.muro_sospeso.x == 1) {
						LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
						LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
					}
					else if (g.muro_sospeso.v == 1){
						for (t = 2; t < 12; t += 2){
							
							if (g.i[g.muro_sospeso.x - t][g.muro_sospeso.y] == 0 &&
								g.i[g.muro_sospeso.x - t][g.muro_sospeso.y + 1] == 0 &&
							g.i[g.muro_sospeso.x - t][g.muro_sospeso.y - 1] == 0){
								
								LCD_Move_Full_Rectangle( &(g.muro_sospeso), 2*(t-2) + 2);
								break;
								
							}
							else if (g.muro_sospeso.x - t == 1){
								if (anyMoves(&g) == 0){
									LCD_Draw_Full_Rectangle(g.muro_sospeso, background_color);
									t = g.muro_sospeso.x;
									r = g.muro_sospeso.y;
									g.i[t][r] = 1;
									Search_free_place ( &(g.muro_sospeso), g.i);
									g.i[t][r] = 0;
									LCD_Draw_Full_Rectangle( g.muro_sospeso, g.muro_sospeso.color );
								}
								else {
									LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
									LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
								}
							break;
							}
						}
					}
					else if (g.muro_sospeso.v == 0){
						for (t = 2; t < 12; t += 2){
							
							if (g.i[g.muro_sospeso.x - t][g.muro_sospeso.y] == 0 &&
								g.i[g.muro_sospeso.x - t - 1][g.muro_sospeso.y] == 0 &&
							g.i[g.muro_sospeso.x - t + 1][g.muro_sospeso.y] == 0){
								
								LCD_Move_Full_Rectangle( &(g.muro_sospeso), 2*(t-2) + 2);
								break;
								
							}
							else if (g.muro_sospeso.x - t == 1){
								if (anyMoves(&g) == 0){
									LCD_Draw_Full_Rectangle(g.muro_sospeso, background_color);
									t = g.muro_sospeso.x;
									r = g.muro_sospeso.y;
									g.i[t][r] = 1;
									Search_free_place ( &(g.muro_sospeso), g.i);
									g.i[t][r] = 0;
									LCD_Draw_Full_Rectangle( g.muro_sospeso, g.muro_sospeso.color );
								}
								else {
									LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
									LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
								}
								break;
							}
						}
					}
					else{
						LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
						LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
					}
					break;
				}
			default:
				break;
		}
	}
	else{
			J_left=0;
	}
	
	if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){	
		
		J_right++;
		switch(J_right){
			case 1:
				if (g.game_mode == 0) {
					int c;
					if (flag){
						GUI_Text(0, 241, (uint8_t *) "                               ", background_color , background_color);
						flag = 0;
					}
					if ((c = Check_right (g.mossa_sospesa.x, g.mossa_sospesa.y, &g))){
						Erase_old_Hmove (&(g.mossa_sospesa));
						g.mossa_sospesa.v = (c-2)*2 + 3;
						Make_new_Hmove (&(g.mossa_sospesa));
					}
				}
				else if (g.game_mode == 1){
				if (g.muro_sospeso.x == 11) {
					LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
					LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
				}
				else if (g.muro_sospeso.v == 1){
					for (t = 2; t < 12; t += 2){
						
						if (g.i[g.muro_sospeso.x + t][g.muro_sospeso.y] == 0 &&
							g.i[g.muro_sospeso.x + t][g.muro_sospeso.y + 1] == 0 &&
						g.i[g.muro_sospeso.x + t][g.muro_sospeso.y - 1] == 0){
							
							LCD_Move_Full_Rectangle( &(g.muro_sospeso), 2*(t-2) + 3);
							break;
							
						}
						else if (g.muro_sospeso.x + t == 11){
							if (anyMoves(&g) == 0){
									LCD_Draw_Full_Rectangle(g.muro_sospeso, background_color);
									t = g.muro_sospeso.x;
									r = g.muro_sospeso.y;
									g.i[t][r] = 1;
									Search_free_place ( &(g.muro_sospeso), g.i);
									g.i[t][r] = 0;
									LCD_Draw_Full_Rectangle( g.muro_sospeso, g.muro_sospeso.color );
								}
							else {
								LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
								LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
							}
							break;
						}
					}
				}
				else if (g.muro_sospeso.v == 0){
					for (t = 2; t < 12; t += 2){
						
						if (g.i[g.muro_sospeso.x + t][g.muro_sospeso.y] == 0 &&
							g.i[g.muro_sospeso.x + t - 1][g.muro_sospeso.y] == 0 &&
						g.i[g.muro_sospeso.x + t + 1][g.muro_sospeso.y] == 0){
							
							LCD_Move_Full_Rectangle( &(g.muro_sospeso), 2*(t-2) + 3);
							break;
							
						}
						else if (g.muro_sospeso.x + t == 11){
							if (anyMoves(&g) == 0){
									LCD_Draw_Full_Rectangle(g.muro_sospeso, background_color);
									t = g.muro_sospeso.x;
									r = g.muro_sospeso.y;
									g.i[t][r] = 1;
									Search_free_place ( &(g.muro_sospeso), g.i);
									g.i[t][r] = 0;
									LCD_Draw_Full_Rectangle( g.muro_sospeso, g.muro_sospeso.color );
								}
							else {
								LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
								LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
							}
							break;
						}
					}
				}
				else{
					LCD_Draw_Full_Rectangle(g.muro_sospeso, error_color);
					LCD_Draw_Full_Rectangle(g.muro_sospeso, g.muro_sospeso.color);
				}
				break;
			}
			default:
				break;
		}
	}
	else{
			J_right=0;
	}
	
	
	/* button management */
	if(down_0 != 0){ 
		if((LPC_GPIO2->FIOPIN & (1<<10)) == 0){	/* INT0 pressed */
			down_0++;				
			
			switch(down_0){
				case 2:	
					Matrix_Initialization(&g);
					LCD_Clear(background_color);
					LCD_DrawGame(&g);
					Positionate_player(1, &g);
					Positionate_player(2, &g);
					SetUp_turn(&g);
					NVIC_EnableIRQ(EINT1_IRQn);
					NVIC_EnableIRQ(EINT2_IRQn);
					break;
				
				default:
					break;
			}
		}
		else {	/* button released */
			down_0 = 0;			
			NVIC_EnableIRQ(EINT0_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 20);     /* External interrupt 0 pin selection */
		}
	}
	
	if(down_1 != 0){ 
		if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){	/* KEY1 pressed */
			down_1++;				
			switch(down_1){
				case 2:	
					if (g.game_mode == 0){
						if ((g.turno == 1 && g.g1.n == 0) || (g.turno == 2 && g.g2.n == 0)){
							GUI_Text(0, 241, (uint8_t *) "   Attenzione: muri finiti!   ", White , error_color);
							flag = 1;
						}
						else{
							g.game_mode = 1;
							Erase_old_Hmove(&(g.mossa_sospesa));
							SetUp_HMoves (&g, background_color);
							Search_free_place(&(g.muro_sospeso), g.i);
							LCD_Draw_Full_Rectangle( g.muro_sospeso, g.muro_sospeso.color );
						}
					}	
					else if (g.game_mode == 1){
						g.game_mode = 0;
						LCD_Draw_Full_Rectangle( g.muro_sospeso, background_color );
						SetUp_HMoves (&g, game_color);
					}
					break;
				default:
					break;
			}
		}
		else {	/* button released */
			down_1 = 0;			
			NVIC_EnableIRQ(EINT1_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	}
	
	if(down_2 != 0){ 
		if((LPC_GPIO2->FIOPIN & (1<<12)) == 0){	/* KEY2 pressed */
			down_2++;				
			switch(down_2){
				case 2:	
					if (g.game_mode) LCD_Rotate_Full_Rectangle(&g);
					break;
				default:
					break;
			}
		}
		else {	/* button released */
			down_2 = 0;			
			NVIC_EnableIRQ(EINT2_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 24);     /* External interrupt 0 pin selection */
		}
	}
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
