/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include <string.h>
#include "lpc17xx.h"
#include "timer.h"
#include "../GLCD/GLCD.h" 
#include "../Game.h"

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

extern G g;
extern uint16_t game_color;
extern uint16_t background_color;

void TIMER0_IRQHandler (void)
{
	if (g.secondi[1] != 0) g.secondi[1] -= 1;
	else{
		if (g.secondi[0] == 0) {      							//fine del turno dovuto alla fine del tempo
			disable_timer(0);
			Erase_old_Hmove(&(g.mossa_sospesa));
			if (g.turno == 1) g.mossa_32bit = MoveOn32Bit(1, 0, 0, g.mossa_sospesa.y, g.mossa_sospesa.x);
			else g.mossa_32bit = MoveOn32Bit(2, 0, 1, g.mossa_sospesa.y, g.mossa_sospesa.x);
			SetUp_HMoves( &g,  background_color );
			if(g.muro_sospeso.x != -1) LCD_Draw_Full_Rectangle(g.muro_sospeso, background_color);
			SetUp_turn(&g);
		}
		else{
			g.secondi[0] -= 1;
			g.secondi[1] = 9;
		}
	}
	PutChar(113, 277, g.secondi[0] + 48, game_color, background_color);
	PutChar(121, 277, g.secondi[1] + 48, game_color, background_color);
  LPC_TIM0->IR = 1;			/* clear interrupt flag */
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
